#/bin/bash
U_PASTA="/var/www/ambulatorio/guias_cassi/"
#
cd $U_PASTA
rm -dfr *
echo "Pasta vazia"
