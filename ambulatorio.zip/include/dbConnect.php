<?php
//
//// Definicoes de banco de dados
//define("DB_SERVER", "localhost");
//define("DB_USER", "buscarta");
//define("DB_PASS", "Bu\$carta5");
//define("DB_NAME", "buscarta_bc");
//
//define("SALT","k?1>,y:23]Mj:>*");
//
//$conexao = mysql_connect(DB_SERVER, DB_USER, DB_PASS);
//$db      = mysql_select_db(DB_NAME, $conexao) or die(mysql_error());
//
//?>
