<?php
/**
 * Created by IntelliJ IDEA.
 * User: 10973787724
 * Date: 08/05/13
 * Time: 16:32
 * To change this template use File | Settings | File Templates.
 */ 
class RelatorioAtestadoPorDiaDTO {

    public $matricula;
    public $nome;
    public $lotacao;
    public $datas;

}
