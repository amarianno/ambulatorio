<?php

require_once('Loader.class.php');

abstract class Persistivel {
    public abstract function getChavePrimaria();
}