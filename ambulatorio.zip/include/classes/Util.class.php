<?php


class Util {

    public static function formataAnoDaTelaComQuatroDigitos($ano) {
        return "20" + $ano;
    }


}
