<?php

final class Constantes {
    const INSERIR = "inserir";
    const EDITAR = "editar";
    const EXCLUIR = "excluir";
    const CONSULTAR = "consultar";
    const OBJETO_USUARIO = "objeto_usuario";
    const SET_PAGINA_INICIAL = 5;
    const TABELA_MAGICCARDS = "magiccards";
    const TABELA_SETS = "sets";
    const TABELA_CARDSSET = "cardsset";
    const TABELA_USERS = "usersbc";
    const TABELA_PARSERS = "parsers";
    const TABELA_PARSERS_USER = "usersbc_parsers";
    const TABELA_HISTORICO = "historico";
    const PWD = "pwd";
}