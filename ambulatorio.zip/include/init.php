<?php

include_once "constantes_.php";

//if (! defined ( "INCLUDE_DIR" ))
//	define ( "INCLUDE_DIR", dirname ( __FILE__ ) );
//if (! defined ( "FUNCTIONS_DIR" ))
//	define ( "FUNCTIONS_DIR", INCLUDE_DIR . "/functions" );
//if (! defined ( "CLASSES_DIR" ))
//	define ( "CLASSES_DIR", INCLUDE_DIR . "/classes" );
//if (! defined ( "IMAGES_DIR" ))
//	define ( "IMAGES_DIR", INCLUDE_DIR . "/images" );
//if (! defined ( "USER_DIR" ))
//	define ( "USER_DIR", INCLUDE_DIR . "/user" );


