<?php

    define('BANCO_MYSQL', 'MYSQL');
    define('BANCO_DE_DADOS', 'MYSQL');
    define('HOST_BANCO', 'localhost');
    define('NOME_BANCO', 'ambulatorio_desenv');
    define('LOGIN_BANCO', 'root');
    define('SENHA_BANCO', 'Bu$carta5');
    define('BANCO_SESSAO', 'banco');