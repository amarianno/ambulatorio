<?php

echo md5($_GET['senha']);
